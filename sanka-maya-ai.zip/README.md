
# Sanka-Maya AI

AI Writer Bot untuk sanka-maya.blogspot.com
100% gratis, jalan di GitHub Actions, tanpa butuh RAM besar. Dibuat untuk laptop Asus A202E RAM 2GB.

## Cara Pakai (Cuma dari HP juga bisa)
1. Buka tab Actions > Sanka Maya AI Writer > Run workflow
2. Isi judul, klik Run
3. Tunggu 1-2 menit, artikel jadi di folder /artikel/
4. Copy file HTML ke Blogger

## Setup Kunci Gratis
Settings > Secrets and variables > Actions > New secret
Name: OPENROUTER_KEY Value: key dari openrouter.ai (model :free gratis)
