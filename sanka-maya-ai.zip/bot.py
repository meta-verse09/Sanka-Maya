
import sys, requests, os, pathlib, datetime

judul = sys.argv[1] if len(sys.argv)>1 else "Arti Angka 11:11"
kategori = sys.argv[2] if len(sys.argv)>2 else "numerologi"

prompt = f"""
Kamu adalah penulis blog Sanka-Maya (sanka-maya.blogspot.com), niche numerologi, tafsir angka, dan lifestyle.
Tugas: Tulis artikel 800-900 kata, bahasa Indonesia santai, tidak kaku.
Judul: {judul}
Kategori: {kategori}

Aturan:
- Format HTML Blogger: gunakan <h2>, <h3>, <p>, <ul><li>
- Jangan sertakan <html><head><body>
- Buka dengan hook 2 paragraf
- Isi 3-4 subheading H2 yang relevan
- Tutup dengan kesimpulan + disclaimer: "Numerologi hanya untuk hiburan dan refleksi diri"
- Di akhir tambahkan 3 keyword SEO
- Gaya tulisan manusia, bukan AI
"""

openrouter_key = os.getenv("OPENROUTER_KEY")
artikel = ""
if openrouter_key:
    try:
        headers = {"Authorization": f"Bearer {openrouter_key}", "Content-Type": "application/json"}
        data = {
            "model": "meta-llama/llama-3.2-3b-instruct:free",
            "messages": [{"role":"user","content":prompt}],
            "max_tokens": 1500
        }
        r = requests.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=data, timeout=90)
        print("OpenRouter status:", r.status_code)
        if r.status_code==200:
            artikel = r.json()['choices'][0]['message']['content']
    except Exception as e:
        print("OpenRouter error:", e)

if not artikel:
    artikel = f"<h2>{judul}</h2><p>Artikel gagal generate, ini template. Kategori: {kategori}. Tanggal: {datetime.date.today()}</p>"

pathlib.Path("artikel").mkdir(exist_ok=True)
safe_name = "".join(c if c.isalnum() else "-" for c in judul)[:40]
out_path = f"artikel/{safe_name}.html"
pathlib.Path(out_path).write_text(artikel, encoding="utf-8")
print(f"Saved to {out_path}")
